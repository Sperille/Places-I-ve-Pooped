//
//  AccountView.swift
//  Places I've Pooped
//

import SwiftUI

struct AccountView: View {
    @EnvironmentObject private var auth: AuthManager
    @EnvironmentObject private var poopManager: PoopManager
    @EnvironmentObject private var groupsManager: GroupsManager
    @EnvironmentObject private var menuState: MenuState
    @EnvironmentObject private var userManager: UserManager

    // My posts
    @State private var myPins: [PoopPin] = []
    @State private var currentFetchToken = UUID()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {

                // Header
                HStack(spacing: 12) {
                    Circle().frame(width: 48, height: 48).opacity(0.15)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(displayName)
                            .font(.title3.weight(.semibold))
                        Text(displayEmail)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                }

                // Current group (if any)
                if let gid = groupsManager.currentGroupID, let gname = groupsManager.currentGroupName {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Current Group").font(.headline)
                        HStack(spacing: 10) {
                            Image(systemName: "person.3")
                            Text(gname)
                            Spacer()
                            Text("ID: \(gid)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                // My recent poops
                VStack(alignment: .leading, spacing: 8) {
                    Text("My Poops").font(.headline)

                    if myPins.isEmpty {
                        Text("You haven’t logged any poops yet.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    } else {
                        VStack(spacing: 8) {
                            ForEach(myPins) { pin in
                                NavigationLink { PoopDetailView(poop: pin) } label: {
                                    PoopInlineRow(pin: pin)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
        }
        .navigationTitle("Account")
        .navigationBarTitleDisplayMode(.large)
        // Top-right SIGN OUT ICON (restored)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button(role: .destructive) { signOut() } label: {
                    Image(systemName: "rectangle.portrait.and.arrow.right")
                        .symbolRenderingMode(.hierarchical)
                        .font(.title3)
                }
                .accessibilityLabel("Sign Out")
            }
        }
        // Load when user resolves / when they change
        .task(id: auth.currentUserRecordID) { await reloadMyPins() }
    }

    private var displayName: String {
        let n = auth.currentUserName.trimmingCharacters(in: .whitespacesAndNewlines)
        return n.isEmpty ? "User" : n
    }

    private var displayEmail: String {
        auth.currentUserEmail.isEmpty ? " " : auth.currentUserEmail
    }

    // MARK: - Loading (tokened so stale callbacks can't overwrite)

    @MainActor
    private func reloadMyPins() async {
        guard let me = auth.currentUserRecordID?.recordName else { return }
        let token = UUID()
        currentFetchToken = token
        poopManager.loadPins(scope: .mine(me)) { pins in
            guard token == self.currentFetchToken else { return }
            self.myPins = pins.sorted(by: { $0.createdAt > $1.createdAt })
        }
    }

    // MARK: - Actions

    private func signOut() {
        groupsManager.leaveGroup()           // clear selection
        auth.signOut()                       // AppRootView will swap to LoginView
        menuState.currentScreen = .dashboard // reset tab/router if you use it
    }
}

// MARK: - Inline Row

private struct PoopInlineRow: View {
    let pin: PoopPin

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(Self.formatDate(pin.createdAt))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Spacer()
                Text(pin.userName)
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1)
            }
            if !pin.locationDescription.isEmpty {
                Text(pin.locationDescription).font(.subheadline)
            }
            if !pin.comment.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Text(pin.comment)
                    .font(.subheadline)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .contentShape(Rectangle())
    }

    private static func formatDate(_ date: Date) -> String {
        let f = RelativeDateTimeFormatter()
        f.unitsStyle = .short
        return f.localizedString(for: date, relativeTo: Date())
    }
}
