import SwiftUI
import CloudKit

struct AddFriendView: View {
    @EnvironmentObject var userManager: UserManager
    @Environment(\.dismiss) private var dismiss

    @State private var query: String = ""
    @State private var results: [FoundUser] = []
    @State private var isSearching: Bool = false
    @State private var errorMessage: String?
    @State private var addingUsername: String?

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                HStack(spacing: 8) {
                    HStack(spacing: 6) {
                        Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                        TextField("Search by username", text: $query)
                            .textInputAutocapitalization(.never)
                            .disableAutocorrection(true)
                            .onSubmit { runSearch(term: query) }
                    }
                    .padding(10)
                    .background(Color(.secondarySystemBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 10))

                    Button { runSearch(term: query) } label: {
                        Text("Search").fontWeight(.semibold)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isSearching)
                }

                if let errorMessage {
                    Text(errorMessage).foregroundColor(.red).font(.footnote)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }

                if isSearching {
                    ProgressView("Searching…").frame(maxWidth: .infinity, alignment: .leading)
                }

                List {
                    ForEach(results) { user in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("@\(user.username)").font(.body.weight(.semibold))
                                if let display = user.displayName, !display.isEmpty {
                                    Text(display).font(.caption).foregroundStyle(.secondary)
                                }
                            }
                            Spacer()
                            Button {
                                addFriend(user: user) // byCode under the hood
                            } label: {
                                if addingUsername == user.username { ProgressView() }
                                else { Text("Add").fontWeight(.semibold) }
                            }
                            .buttonStyle(.borderedProminent)
                            .disabled(addingUsername != nil)
                        }
                    }
                }
                .listStyle(.plain)

                Spacer(minLength: 0)
            }
            .padding()
            .navigationTitle("Add Friend")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarLeading) { Button("Close") { dismiss() } } }
        }
    }

    func runSearch(term: String) {
        let q = term.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return }
        isSearching = true; errorMessage = nil; results = []

        let publicDB = CKContainer.default().publicCloudDatabase
        let qLower = q.lowercased()

        // Production-safe, indexed field
        let predicate = NSPredicate(format: "username_lc BEGINSWITH %@", qLower)
        let ckQuery = CKQuery(recordType: "User", predicate: predicate)
        ckQuery.sortDescriptors = [NSSortDescriptor(key: "username_lc", ascending: true)]

        var hits: [FoundUser] = []

        let op = CKQueryOperation(query: ckQuery)
        op.resultsLimit = 50
        op.recordMatchedBlock = { _, result in
            if case .success(let record) = result {
                let username = (record["username"] as? String) ?? ""
                let display  = record["email"] as? String // or your display field if you have one
                guard !username.isEmpty else { return }
                hits.append(FoundUser(id: record.recordID.recordName,
                                      username: username,
                                      displayName: display))
            }
        }
        op.queryResultBlock = { _ in
            DispatchQueue.main.async {
                self.isSearching = false
                self.results = hits
            }
        }
        publicDB.add(op)
    }

    private func addFriend(user: FoundUser) {
        addingUsername = user.username
        userManager.addFriend(byCode: user.id) { success in
            DispatchQueue.main.async {
                if success { dismiss() }
                else {
                    self.errorMessage = "Couldn’t add @\(user.username). They may already be your friend."
                    self.addingUsername = nil
                }
            }
        }
    }
}

private struct FoundUser: Identifiable {
    let id: String            // CKRecordID.recordName (friend code)
    let username: String
    let displayName: String?
}
