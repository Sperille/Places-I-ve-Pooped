//
//  AuthManager.swift
//  Places I've Pooped
//

import Foundation
import SwiftUI
import CloudKit
import AuthenticationServices
import UIKit

@MainActor
final class AuthManager: NSObject, ObservableObject {

    // MARK: - Published session state
    @Published var isAuthenticated: Bool = false
    @Published var currentUserName: String = "User"
    @Published var currentUserEmail: String = ""
    @Published var currentUserRecordID: CKRecord.ID?

    /// Shown only if we couldn't get a name from Apple on first sign-in.
    @Published var requiresDisplayNameCapture: Bool = false

    // MARK: - Private
    private var authorizationController: ASAuthorizationController?
    private var revocationObserver: NSObjectProtocol?
    private var pendingAppleUserID: String?

    // Local storage keys
    private let kDisplayNameKey  = "auth.displayName"
    private let kAppleUserIDKey  = "auth.apple.userID"
    private let kUserRecordKey   = "auth.user.recordName"

    // MARK: - Init / Deinit
    override init() {
        super.init()
        revocationObserver = NotificationCenter.default.addObserver(
            forName: ASAuthorizationAppleIDProvider.credentialRevokedNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in self?.signOut() }
        }
    }

    deinit {
        if let obs = revocationObserver {
            NotificationCenter.default.removeObserver(obs)
        }
    }

    // MARK: - Rehydrate at launch
    func rehydrateOnLaunch() {
        let defaults = UserDefaults.standard

        if let savedName = defaults.string(forKey: kDisplayNameKey), !savedName.isEmpty {
            currentUserName = savedName
        }

        if let appleID = defaults.string(forKey: kAppleUserIDKey), !appleID.isEmpty {
            ASAuthorizationAppleIDProvider().getCredentialState(forUserID: appleID) { [weak self] state, _ in
                Task { @MainActor in
                    switch state {
                    case .authorized:
                        await self?.fetchAppleUser(appleID)
                        self?.isAuthenticated = true
                    default:
                        self?.signOut()
                    }
                }
            }
            return
        }

        if let recordName = defaults.string(forKey: kUserRecordKey), !recordName.isEmpty {
            Task { await fetchUserByRecordName(recordName) }
        }
    }

    // MARK: - Apple Sign In
    func startSignInWithApple() {
        let provider = ASAuthorizationAppleIDProvider()
        let request  = provider.createRequest()
        request.requestedScopes = [.fullName, .email]

        let controller = ASAuthorizationController(authorizationRequests: [request])
        controller.delegate = self
        controller.presentationContextProvider = self
        controller.performRequests()
        self.authorizationController = controller
    }

    // MARK: - Email/Username Sign Up
    func signUp(email: String, username: String, password: String) async throws {
        let emailLC = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let uname   = username.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !emailLC.isEmpty, !uname.isEmpty, !password.isEmpty else {
            throw NSError(domain: "SignUp", code: -1,
                          userInfo: [NSLocalizedDescriptionKey: "Please fill all fields."])
        }

        let rec = CKRecord(recordType: "User")
        rec["email"] = email as CKRecordValue
        rec["email_lc"] = emailLC as CKRecordValue
        rec["username"] = uname as CKRecordValue
        rec["username_lc"] = uname.lowercased() as CKRecordValue
        rec["passwordHash"] = password as CKRecordValue   // NOTE: for demo only; hash in production
        rec["signInMethod"] = "email" as CKRecordValue

        let saved = try await CKEnv.privateDB.save(rec)

        currentUserRecordID = saved.recordID
        currentUserName = uname
        currentUserEmail = email
        isAuthenticated = true

        let d = UserDefaults.standard
        d.set(uname, forKey: kDisplayNameKey)
        d.set(saved.recordID.recordName, forKey: kUserRecordKey)
        d.removeObject(forKey: kAppleUserIDKey)
    }

    // MARK: - Email/Username Sign In (NEW)
    /// Sign in using email OR username + password.
    func signIn(identifier: String, password: String) async throws {
        let idLC = identifier.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !idLC.isEmpty, !password.isEmpty else {
            throw NSError(domain: "SignIn", code: -1,
                          userInfo: [NSLocalizedDescriptionKey: "Enter email/username and password."])
        }

        let predicate = NSPredicate(format: "email_lc == %@ OR username_lc == %@", idLC, idLC)
        let query = CKQuery(recordType: "User", predicate: predicate)

        // Fetch the first match from private DB
        let recs: [CKRecord] = try await withCheckedThrowingContinuation { cont in
            CKEnv.privateDB.perform(query, inZoneWith: nil) { records, error in
                if let error = error { cont.resume(throwing: error); return }
                cont.resume(returning: records ?? [])
            }
        }

        guard let rec = recs.first else {
            throw NSError(domain: "SignIn", code: -2,
                          userInfo: [NSLocalizedDescriptionKey: "Account not found."])
        }

        // Password check (demo). In production, verify a hash.
        let stored = (rec["passwordHash"] as? String) ?? ""
        guard stored == password else {
            throw NSError(domain: "SignIn", code: -3,
                          userInfo: [NSLocalizedDescriptionKey: "Incorrect password."])
        }

        // Success → set state
        currentUserRecordID = rec.recordID
        currentUserName = (rec["username"] as? String) ?? "User"
        currentUserEmail = (rec["email"] as? String) ?? ""
        isAuthenticated = true

        let d = UserDefaults.standard
        d.set(currentUserName, forKey: kDisplayNameKey)
        d.set(rec.recordID.recordName, forKey: kUserRecordKey)
        d.removeObject(forKey: kAppleUserIDKey)
    }

    // MARK: - Submit name (if Apple didn’t give it)
    func submitDisplayName(_ name: String) async {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }

        let recordID: CKRecord.ID? = {
            if let apple = pendingAppleUserID { return CKRecord.ID(recordName: apple) }
            return currentUserRecordID
        }()

        guard let id = recordID else { return }

        do {
            let rec: CKRecord
            do {
                rec = try await CKEnv.privateDB.record(for: id)
            } catch {
                rec = CKRecord(recordType: "User", recordID: id)
            }

            rec["username"] = trimmed as CKRecordValue
            rec["username_lc"] = trimmed.lowercased() as CKRecordValue

            let saved = try await CKEnv.privateDB.save(rec)

            currentUserRecordID = saved.recordID
            currentUserName = trimmed
            isAuthenticated = true
            requiresDisplayNameCapture = false
            pendingAppleUserID = nil

            UserDefaults.standard.set(trimmed, forKey: kDisplayNameKey)
            if saved.recordID.recordName == pendingAppleUserID {
                UserDefaults.standard.set(saved.recordID.recordName, forKey: kAppleUserIDKey)
                UserDefaults.standard.removeObject(forKey: kUserRecordKey)
            }
        } catch {
            print("❌ submitDisplayName error: \(error.localizedDescription)")
        }
    }

    // MARK: - Sign Out
    func signOut() {
        isAuthenticated = false
        currentUserName = "User"
        currentUserEmail = ""
        currentUserRecordID = nil
        requiresDisplayNameCapture = false
        pendingAppleUserID = nil

        let d = UserDefaults.standard
        d.removeObject(forKey: kDisplayNameKey)
        d.removeObject(forKey: kAppleUserIDKey)
        d.removeObject(forKey: kUserRecordKey)
    }

    // MARK: - Helpers
    private func fetchAppleUser(_ appleUserID: String) async {
        let id = CKRecord.ID(recordName: appleUserID)
        do {
            let rec = try await CKEnv.privateDB.record(for: id)
            currentUserRecordID = rec.recordID
            currentUserName = (rec["username"] as? String) ?? "User"
            currentUserEmail = (rec["email"] as? String) ?? ""
            isAuthenticated = true

            UserDefaults.standard.set(currentUserName, forKey: kDisplayNameKey)
            UserDefaults.standard.set(appleUserID, forKey: kAppleUserIDKey)

            if currentUserName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                || currentUserName == "User" {
                pendingAppleUserID = appleUserID
                requiresDisplayNameCapture = true
            }
        } catch {
            signOut()
        }
    }

    private func fetchUserByRecordName(_ recordName: String) async {
        let id = CKRecord.ID(recordName: recordName)
        do {
            let rec = try await CKEnv.privateDB.record(for: id)
            currentUserRecordID = rec.recordID
            currentUserName = (rec["username"] as? String) ?? "User"
            currentUserEmail = (rec["email"] as? String) ?? ""
            isAuthenticated = true

            UserDefaults.standard.set(currentUserName, forKey: kDisplayNameKey)
            UserDefaults.standard.set(recordName, forKey: kUserRecordKey)
        } catch {
            signOut()
        }
    }
}

// MARK: - ASAuthorizationControllerDelegate
extension AuthManager: ASAuthorizationControllerDelegate {
    func authorizationController(controller: ASAuthorizationController,
                                 didCompleteWithAuthorization authorization: ASAuthorization) {
        guard let credential = authorization.credential as? ASAuthorizationAppleIDCredential else { return }

        let appleUserID = credential.user
        let d = UserDefaults.standard

        // Apple only provides name/email on FIRST auth
        let formatter = PersonNameComponentsFormatter()
        let fullName = formatter.string(from: credential.fullName ?? PersonNameComponents()).trimmingCharacters(in: .whitespacesAndNewlines)
        let email = credential.email ?? ""

        Task { @MainActor in
            let recordID = CKRecord.ID(recordName: appleUserID)

            do {
                // Try existing user
                let rec = try await CKEnv.privateDB.record(for: recordID)

                var needsSave = false
                if !fullName.isEmpty, (rec["username"] as? String)?.isEmpty ?? true {
                    rec["username"] = fullName as CKRecordValue
                    rec["username_lc"] = fullName.lowercased() as CKRecordValue
                    needsSave = true
                }
                if !email.isEmpty, (rec["email"] as? String)?.isEmpty ?? true {
                    rec["email"] = email as CKRecordValue
                    rec["email_lc"] = email.lowercased() as CKRecordValue
                    needsSave = true
                }
                let saved = needsSave ? try await CKEnv.privateDB.save(rec) : rec

                currentUserRecordID = saved.recordID
                currentUserName = (saved["username"] as? String) ?? (!fullName.isEmpty ? fullName : "User")
                currentUserEmail = (saved["email"] as? String) ?? email
                isAuthenticated = true

                if currentUserName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                    || currentUserName == "User" {
                    pendingAppleUserID = appleUserID
                    requiresDisplayNameCapture = true
                }

            } catch {
                // New user → create
                let rec = CKRecord(recordType: "User", recordID: recordID)
                if !email.isEmpty {
                    rec["email"] = email as CKRecordValue
                    rec["email_lc"] = email.lowercased() as CKRecordValue
                }
                if !fullName.isEmpty {
                    rec["username"] = fullName as CKRecordValue
                    rec["username_lc"] = fullName.lowercased() as CKRecordValue
                }
                rec["appleUserID"] = appleUserID as CKRecordValue
                rec["signInMethod"] = "apple" as CKRecordValue

                let saved = try await CKEnv.privateDB.save(rec)

                currentUserRecordID = saved.recordID
                currentUserName = (saved["username"] as? String) ?? "User"
                currentUserEmail = (saved["email"] as? String) ?? ""
                isAuthenticated = true

                if currentUserName == "User" {
                    pendingAppleUserID = appleUserID
                    requiresDisplayNameCapture = true
                }
            }

            // Persist locally
            d.set(currentUserName, forKey: kDisplayNameKey)
            d.set(appleUserID, forKey: kAppleUserIDKey)
            d.removeObject(forKey: kUserRecordKey)
        }
    }

    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        print("❌ Apple Sign-In failed: \(error.localizedDescription)")
        signOut()
    }
}

// MARK: - ASAuthorizationControllerPresentationContextProviding
extension AuthManager: ASAuthorizationControllerPresentationContextProviding {
    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow } ?? UIWindow()
    }
}
