//
//  ColorPickerSheet.swift
//  Places I've Pooped
//

import SwiftUI
import CloudKit

struct ColorPickerSheet: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var groupsManager: GroupsManager
    @EnvironmentObject var userManager: UserManager

    var groupID: String
    var onComplete: () -> Void

    @State private var selectedColor: Color = .blue
    @State private var isSaving = false
    @State private var errorMessage: String?

    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                Text("Choose Your Poop Pin Color")
                    .font(.headline)

                ColorPicker("Pin Color", selection: $selectedColor, supportsOpacity: false)
                    .padding()
                    .frame(maxWidth: 300)

                Rectangle()
                    .fill(selectedColor)
                    .frame(height: 60)
                    .cornerRadius(12)
                    .overlay(
                        Text(selectedColor.toHex()) // uses your existing extension
                            .foregroundColor(.white)
                            .bold()
                    )

                if let error = errorMessage {
                    Text(error)
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                }

                Spacer()

                Button(isSaving ? "Saving..." : "Save") {
                    saveColorChoice()
                }
                .disabled(isSaving)
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color("PoopBrown"))
                .foregroundColor(.white)
                .cornerRadius(10)
            }
            .padding()
            .navigationTitle("Pick Pin Color")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func saveColorChoice() {
        let hex = selectedColor.toHex()
        isSaving = true
        errorMessage = nil

        checkColorTakenInGroup(colorHex: hex, groupID: groupID) { taken, err in
            if let err {
                self.isSaving = false
                self.errorMessage = "Check failed: \(err.localizedDescription)"
                return
            }
            guard taken == false else {
                self.isSaving = false
                self.errorMessage = "Color already taken in this group. Please choose another."
                return
            }
            self.finishSave(hex: hex)
        }
    }

    private func finishSave(hex: String) {
        let rec = CKRecord(recordType: "GroupMember")
        rec["groupID"]  = groupID as CKRecordValue
        rec["userID"]   = (userManager.currentUserID ?? "anonymous") as CKRecordValue
        rec["name"]     = (userManager.currentUserName ?? "Anonymous") as CKRecordValue
        rec["colorHex"] = hex as CKRecordValue
        rec["joinedAt"] = Date() as CKRecordValue

        let publicDB = CKContainer.default().publicCloudDatabase
        publicDB.save(rec) { _, error in
            DispatchQueue.main.async {
                self.isSaving = false
                if let error {
                    self.errorMessage = "Failed to save: \(error.localizedDescription)"
                    return
                }
                groupsManager.joinGroup(groupID: groupID)
                onComplete()
                dismiss()
            }
        }
    }

    private func checkColorTakenInGroup(colorHex: String,
                                        groupID: String,
                                        completion: @escaping (Bool, Error?) -> Void) {
        let pred = NSCompoundPredicate(andPredicateWithSubpredicates: [
            NSPredicate(format: "groupID == %@", groupID),
            NSPredicate(format: "colorHex == %@", colorHex)
        ])
        let query = CKQuery(recordType: "GroupMember", predicate: pred)
        let publicDB = CKContainer.default().publicCloudDatabase
        publicDB.perform(query, inZoneWith: nil) { recs, err in
            DispatchQueue.main.async {
                if let err { completion(false, err); return }
                completion(!((recs ?? []).isEmpty), nil)
            }
        }
    }
}
