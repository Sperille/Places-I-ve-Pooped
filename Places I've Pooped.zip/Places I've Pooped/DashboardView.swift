//
//  DashboardView.swift
//  Places I've Pooped
//

import SwiftUI
import CoreLocation

struct DashboardView: View {
    @EnvironmentObject private var menuState: MenuState
    @EnvironmentObject private var poopManager: PoopManager
    @EnvironmentObject private var auth: AuthManager
    @EnvironmentObject private var groupsManager: GroupsManager
    @EnvironmentObject private var userManager: UserManager

    @State private var myPins: [PoopPin] = []
    @State private var groupPins: [PoopPin] = []
    @State private var friendPins: [PoopPin] = []

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                let combined = mergeAllPins()
                if combined.isEmpty {
                    FallbackEmpty(allEmpty: true)
                } else {
                    VStack(spacing: 8) {
                        ForEach(combined) { pin in
                            NavigationLink { PoopDetailView(poop: pin) } label: {
                                PoopInlineCard(pin: pin)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
        }
        .navigationTitle("Dashboard")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            // restore Account button (no refresh icon)
            ToolbarItem(placement: .topBarTrailing) {
                Button { menuState.currentScreen = .account } label: {
                    Image(systemName: "person.crop.circle.fill")
                        .symbolRenderingMode(.hierarchical)
                        .font(.title2)
                }
                .accessibilityLabel("Account")
            }
        }
        .task {
            fetchAllFeeds()
            poopManager.fetchPoopPins()              // shared cache (MapView uses this too)
            deriveLists(from: poopManager.poopPins)
        }
        .onReceive(poopManager.$poopPins) { pins in
            deriveLists(from: pins)
        }
        .onChange(of: groupsManager.currentGroupID) { _ in
            fetchGroupFeed(); deriveLists(from: poopManager.poopPins)
        }
        .onChange(of: userManager.friends.count) { _ in
            fetchFriendsFeed(); deriveLists(from: poopManager.poopPins)
        }
    }

    // MARK: - Data helpers (no layout change)
    private func viewerID() -> String? {
        // ✅ fallback to UserManager if AuthManager recordID is nil
        auth.currentUserRecordID?.recordName ?? userManager.currentUserID
    }

    private func deriveLists(from pins: [PoopPin]) {
        let uid = viewerID()
        let gid = groupsManager.currentGroupID
        let friendIDs = userManager.friends.map { $0.id }

        myPins = uid.map { id in pins.filter { $0.userID == id } } ?? []
        groupPins = (gid?.isEmpty == false) ? pins.filter { $0.groupID == gid } : []
        friendPins = friendIDs.isEmpty ? [] : pins.filter { friendIDs.contains($0.userID) }
    }

    private func fetchAllFeeds() { fetchMyFeed(); fetchGroupFeed(); fetchFriendsFeed() }

    private func fetchMyFeed() {
        guard let uid = viewerID() else { myPins = []; return }
        poopManager.loadPins(scope: .mine(uid)) { myPins = $0 }
    }

    private func fetchGroupFeed() {
        guard let gid = groupsManager.currentGroupID, !gid.isEmpty else { groupPins = []; return }
        poopManager.loadPins(scope: .group(gid)) { groupPins = $0 }
    }

    private func fetchFriendsFeed() {
        let ids = userManager.friends.map { $0.id }
        guard !ids.isEmpty else { friendPins = []; return }
        poopManager.loadPins(scope: .friends(ids)) { friendPins = $0 }
    }

    private func mergeAllPins() -> [PoopPin] {
        var map: [String: PoopPin] = [:]
        for p in myPins + groupPins + friendPins { map[p.id] = p }
        return map.values.sorted(by: { $0.createdAt > $1.createdAt })
    }
}
// MARK: - Empty State (unchanged visuals)
private struct FallbackEmpty: View {
    let allEmpty: Bool
    var body: some View {
        Group {
            if allEmpty {
                VStack(spacing: 6) {
                    Text("No poops logged yet").font(.headline)
                    Text("Tap “Log a Poop” to add your first one.")
                        .foregroundStyle(.secondary)
                        .font(.footnote)
                }
                .frame(maxWidth: .infinity, minHeight: 160)
                .padding(.top, 4)
            }
        }
    }
}

// MARK: - Inline Card (unchanged visuals)
private struct PoopInlineCard: View {
    let pin: PoopPin

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline) {
                Text(pin.userName).font(.headline).lineLimit(1)
                Spacer()
                Text(Self.formatDate(pin.createdAt))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            if !pin.locationDescription.isEmpty {
                Text(pin.locationDescription).font(.subheadline)
            }
            if !pin.comment.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                Text(pin.comment)
                    .font(.subheadline)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .contentShape(Rectangle())
    }

    private static func formatDate(_ date: Date) -> String {
        let f = RelativeDateTimeFormatter()
        f.unitsStyle = .short
        return f.localizedString(for: date, relativeTo: Date())
    }
}
