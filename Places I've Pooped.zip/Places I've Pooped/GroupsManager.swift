//
//  GroupsManager.swift
//  Places I've Pooped
//

import Foundation
import CloudKit
import SwiftUI

final class GroupsManager: ObservableObject {
    @Published var members: [GroupMember] = []
    @Published var currentGroupID: String?
    @Published var currentGroupName: String?

    private let privateDB = CKContainer.default().privateCloudDatabase
    private let publicDB  = CKContainer.default().publicCloudDatabase

    // UserDefaults keys for persistence
    private let kGroupIDKey   = "groups.current.id"
    private let kGroupNameKey = "groups.current.name"

    init() {
        // Restore persisted group selection
        let d = UserDefaults.standard
        self.currentGroupID = d.string(forKey: kGroupIDKey)
        self.currentGroupName = d.string(forKey: kGroupNameKey)
        if let gid = currentGroupID {
            fetchCurrentGroupName()
            fetchMembers(groupID: gid)
        }
    }

    // MARK: - Create Group (PUBLIC DB)
    func createGroup(name: String, completion: @escaping (Result<CKRecord.ID, Error>) -> Void) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            completion(.failure(NSError(
                domain: "Group",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "Group name required."]
            )))
            return
        }

        let (userID, userName) = self.currentUserIdentifier()

        let record = CKRecord(recordType: "Group")
        record["name"] = trimmed as CKRecordValue
        record["createdAt"] = Date() as CKRecordValue
        record["ownerID"] = userID as CKRecordValue
        record["inviteCode"] = Self.generateInviteCode() as CKRecordValue

        publicDB.save(record) { [weak self] rec, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
                return
            }
            guard let rec = rec else {
                DispatchQueue.main.async {
                    completion(.failure(NSError(
                        domain: "Group",
                        code: -2,
                        userInfo: [NSLocalizedDescriptionKey: "No record returned from CloudKit."]
                    )))
                }
                return
            }
            // Add creator as first member
            self?.ensureMembership(groupID: rec.recordID.recordName, userID: userID, userName: userName) { _ in
                DispatchQueue.main.async {
                    self?.currentGroupID = rec.recordID.recordName
                    self?.currentGroupName = trimmed
                    self?.persistSelection()
                    self?.fetchMembers(groupID: rec.recordID.recordName)
                    self?.fetchCurrentGroupName()
                    completion(.success(rec.recordID))
                }
            }
        }
    }

    // MARK: - Search (PUBLIC DB; Production-safe predicate)
    func searchGroups(query: String, completion: @escaping (Result<[CKRecord], Error>) -> Void) {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { completion(.success([])); return }

        // CloudKit Production: use BEGINSWITH and merge a few casings.
        let terms = Array(Set([q, q.capitalized, q.lowercased()]))
        var pending = terms.count
        var results: [CKRecord] = []
        let lock = NSLock()

        func finishSuccess() {
            // De-dupe by recordID
            let unique = Dictionary(grouping: results, by: { $0.recordID }).compactMap { $0.value.first }
            completion(.success(unique))
        }

        for term in terms {
            let predicate = NSPredicate(format: "name BEGINSWITH %@", term)
            let ckQuery = CKQuery(recordType: "Group", predicate: predicate)
            let op = CKQueryOperation(query: ckQuery)
            op.resultsLimit = 50
            op.recordMatchedBlock = { _, result in
                if case .success(let record) = result {
                    lock.lock(); results.append(record); lock.unlock()
                }
            }
            op.queryResultBlock = { final in
                DispatchQueue.main.async {
                    pending -= 1
                    if pending == 0 {
                        switch final {
                        case .success:
                            finishSuccess()
                        case .failure(let err):
                            completion(.failure(err))
                        }
                    }
                }
            }
            publicDB.add(op)
        }
    }

    // MARK: - Join / Leave
    func joinGroup(groupID: String, name: String? = nil) {
        let (userID, userName) = self.currentUserIdentifier()

        ensureMembership(groupID: groupID, userID: userID, userName: userName) { [weak self] _ in
            DispatchQueue.main.async {
                self?.currentGroupID = groupID
                if let name { self?.currentGroupName = name }
                self?.persistSelection()
                self?.fetchMembers(groupID: groupID)
                self?.fetchCurrentGroupName()
            }
        }
    }

    func leaveGroup(completion: (() -> Void)? = nil) {
        currentGroupID = nil
        currentGroupName = nil
        members = []
        // Clear persisted selection
        let d = UserDefaults.standard
        d.removeObject(forKey: kGroupIDKey)
        d.removeObject(forKey: kGroupNameKey)
        completion?()
    }

    // MARK: - Members
    func fetchMembers(groupID: String) {
        let predicate = NSPredicate(format: "groupID == %@", groupID)
        let q = CKQuery(recordType: "GroupMember", predicate: predicate)
        let op = CKQueryOperation(query: q)
        var fetched: [GroupMember] = []

        op.recordMatchedBlock = { _, result in
            if case .success(let rec) = result {
                let id = rec.recordID.recordName
                let userID = rec["userID"] as? String ?? id
                let name = rec["userName"] as? String ?? (rec["name"] as? String) ?? "User"
                let colorHex = rec["colorHex"] as? String
                let color = GroupsManager.color(fromHex: colorHex) ?? .blue
                let joinedAt = (rec["joinedAt"] as? Date) ?? (rec["createdAt"] as? Date) ?? (rec.creationDate ?? Date())
                // Adjust to your GroupMember init as needed:
                fetched.append(GroupMember(id: id, userID: userID, name: name, color: color, joinedAt: joinedAt))
            }
        }
        op.queryResultBlock = { [weak self] res in
            DispatchQueue.main.async {
                switch res {
                case .success:
                    self?.members = fetched.sorted(by: { $0.joinedAt < $1.joinedAt })
                case .failure:
                    self?.members = fetched
                }
            }
        }
        publicDB.add(op)
    }

    // MARK: - Group Name
    func fetchCurrentGroupName() {
        guard let gid = currentGroupID else { return }
        let id = CKRecord.ID(recordName: gid)
        publicDB.fetch(withRecordID: id) { [weak self] rec, _ in
            DispatchQueue.main.async {
                if let rec = rec {
                    let name = rec["name"] as? String
                    if let name, !name.isEmpty {
                        self?.currentGroupName = name
                        self?.persistSelection()
                    }
                }
            }
        }
    }

    // MARK: - Helpers

    private func persistSelection() {
        let d = UserDefaults.standard
        d.setValue(currentGroupID, forKey: kGroupIDKey)
        d.setValue(currentGroupName, forKey: kGroupNameKey)
    }

    /// Ensure a GroupMember exists for (groupID,userID). Creates it if missing.
    private func ensureMembership(groupID: String, userID: String, userName: String, completion: @escaping (Bool) -> Void) {
        let predicate = NSPredicate(format: "groupID == %@ AND userID == %@", groupID, userID)
        let q = CKQuery(recordType: "GroupMember", predicate: predicate)
        publicDB.perform(q, inZoneWith: nil) { [weak self] records, _ in
            if let records, !records.isEmpty {
                DispatchQueue.main.async { completion(true) }
                return
            }
            // Create a new membership record
            let rec = CKRecord(recordType: "GroupMember")
            rec["groupID"] = groupID as CKRecordValue
            rec["userID"] = userID as CKRecordValue
            rec["userName"] = userName as CKRecordValue
            rec["name"] = userName as CKRecordValue
            rec["name_lc"] = userName.lowercased() as CKRecordValue
            rec["createdAt"] = Date() as CKRecordValue
            rec["joinedAt"] = Date() as CKRecordValue
            rec["colorHex"] = Self.defaultMemberColorHex() as CKRecordValue

            self?.publicDB.save(rec) { _, _ in
                DispatchQueue.main.async { completion(true) }
            }
        }
    }

    /// Pulls user id/name from our AuthManager/UserDefaults.
    private func currentUserIdentifier() -> (String, String) {
        let d = UserDefaults.standard
        if let appleID = d.string(forKey: "auth.apple.userID"), !appleID.isEmpty {
            let name = d.string(forKey: "auth.displayName") ?? "User"
            return (appleID, name)
        }
        if let recordName = d.string(forKey: "auth.user.recordName"), !recordName.isEmpty {
            let name = d.string(forKey: "auth.displayName") ?? "User"
            return (recordName, name)
        }
        // Fallback (should not happen after login)
        return (UUID().uuidString, "User")
    }

    private static func generateInviteCode() -> String {
        let chars = Array("ABCDEFGHJKLMNPQRSTUVWXYZ23456789")
        return String((0..<6).map { _ in chars.randomElement()! })
    }

    private static func defaultMemberColorHex() -> String {
        return "#8B5E3C"
    }

    private static func color(fromHex hex: String?) -> Color? {
        guard var s = hex?.trimmingCharacters(in: .whitespacesAndNewlines), !s.isEmpty else { return nil }
        if s.hasPrefix("#") { s.removeFirst() }
        guard let v = UInt64(s, radix: 16) else { return nil }
        let r, g, b: Double
        if s.count == 6 {
            r = Double((v >> 16) & 0xFF) / 255.0
            g = Double((v >> 8) & 0xFF) / 255.0
            b = Double(v & 0xFF) / 255.0
            return Color(red: r, green: g, blue: b)
        } else if s.count == 8 {
            let r8 = Double((v >> 24) & 0xFF) / 255.0
            let g8 = Double((v >> 16) & 0xFF) / 255.0
            let b8 = Double((v >> 8)  & 0xFF) / 255.0
            let a8 = Double(v & 0xFF) / 255.0
            return Color(red: r8, green: g8, blue: b8).opacity(a8)
        }
        return nil
    }
}
