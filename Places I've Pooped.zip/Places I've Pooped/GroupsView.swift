//
//  GroupsView.swift
//  Places I've Pooped
//

import SwiftUI

struct GroupsView: View {
    @EnvironmentObject private var groupsManager: GroupsManager
    @EnvironmentObject private var menuState: MenuState

    @State private var showJoin = false
    @State private var showCreate = false
    @State private var showLeaveConfirm = false

    var body: some View {
        Group {
            if let groupID = groupsManager.currentGroupID {
                List {
                    // Current group header
                    Section("Your Group") {
                        HStack(spacing: 12) {
                            Circle().frame(width: 36, height: 36).opacity(0.15)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(groupsManager.currentGroupName ?? "Your Group")
                                    .font(.body.weight(.semibold))
                                Text("ID: \(groupID)")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.footnote.weight(.semibold))
                                .foregroundStyle(.tertiary)
                        }
                        .contentShape(Rectangle())
                    }

                    // Members list (only when we have members)
                    if !groupsManager.members.isEmpty {
                        Section("Members") {
                            ForEach(groupsManager.members) { m in
                                GroupMemberRow(member: m)
                            }
                        }
                    }

                    // Leave group
                    Section {
                        Button(role: .destructive) {
                            showLeaveConfirm = true
                        } label: {
                            Label("Leave Group", systemImage: "rectangle.portrait.and.arrow.right")
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .confirmationDialog("Leave this group?",
                                    isPresented: $showLeaveConfirm,
                                    titleVisibility: .visible) {
                    Button("Leave Group", role: .destructive) {
                        groupsManager.leaveGroup()
                    }
                    Button("Cancel", role: .cancel) { }
                } message: {
                    Text("You’ll be removed from the current group on this device. (No data will be deleted from CloudKit.)")
                }
                // Refresh members whenever the selected group changes
                .task(id: groupsManager.currentGroupID) {
                    if let gid = groupsManager.currentGroupID {
                        groupsManager.fetchMembers(groupID: gid)
                        groupsManager.fetchCurrentGroupName()
                    }
                }

            } else {
                // Empty state (no group yet)
                ScrollView {
                    VStack(spacing: 20) {
                        Image(systemName: "person.3.sequence.fill")
                            .font(.system(size: 52, weight: .semibold))
                            .foregroundStyle(.secondary)
                        Text("No Groups Yet").font(.title2.bold())
                        Text("Join an existing group or create one to start sharing.")
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.secondary)

                        HStack(spacing: 12) {
                            Button {
                                showJoin = true
                            } label: {
                                Label("Join Group", systemImage: "magnifyingglass")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.bordered)
                            .tint(.accentColor)

                            Button {
                                showCreate = true
                            } label: {
                                Label("Create Group", systemImage: "plus.circle.fill")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.borderedProminent)
                        }
                        .padding(.top, 4)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 48)
                    .padding(.horizontal)
                }
            }
        }
        .navigationTitle("Groups")
        .navigationBarTitleDisplayMode(.large)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { menuState.currentScreen = .account } label: {
                    Image(systemName: "person.crop.circle.fill")
                        .symbolRenderingMode(.hierarchical)
                        .font(.title2)
                }
            }
        }
        .sheet(isPresented: $showJoin) {
            JoinGroupView()
                .environmentObject(groupsManager)
        }
        .sheet(isPresented: $showCreate) {
            SearchAndCreateGroupView()
                .environmentObject(groupsManager)
        }
    }
}

// MARK: - Member Row

private struct GroupMemberRow: View {
    let member: GroupMember

    var body: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(member.color)
                .frame(width: 10, height: 10)

            Text(member.name)
                .font(.subheadline)
                .lineLimit(1)

            Spacer()

            Text(member.joinedAt, style: .date)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 6)
    }
}
