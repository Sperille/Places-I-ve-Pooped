//
//  LogPoopView.swift
//  Places I've Pooped
//
//  Created by Steven Perille on 7/3/25.
//

import SwiftUI
import CoreLocation
import PhotosUI

struct LogPoopView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var poopManager: PoopManager
    @EnvironmentObject var locationManager: LocationManager
    @EnvironmentObject var auth: AuthManager
    @EnvironmentObject var groups: GroupsManager

    // Location
    @State private var locationDescription: String = ""
    private let geocoder = CLGeocoder()

    // Ratings (1–5)
    @State private var tpRating: Int = 3
    @State private var cleanliness: Int = 3
    @State private var privacy: Int = 3
    @State private var plumbing: Int = 3
    @State private var overallVibes: Int = 3

    // Comment
    @State private var comment: String = ""

    // Photo
    @State private var pickerItem: PhotosPickerItem?
    @State private var imageData: Data?
    @State private var imageURL: URL?

    // UI
    @State private var isSaving: Bool = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(spacing: 16) {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {

                    // Header
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Log a Poop")
                            .font(.title2.bold())
                        Text("Share your experience and help your group find the best spots.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    // Location
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(spacing: 8) {
                            Image(systemName: "mappin.and.ellipse")
                            Text("Location")
                                .font(.subheadline.weight(.semibold))
                            Spacer()
                        }
                        TextField("Where are you?", text: $locationDescription)
                            .textInputAutocapitalization(.sentences)
                            .padding(12)
                            .background(.ultraThinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.thinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    // Ratings
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Ratings")
                            .font(.subheadline.weight(.semibold))
                        StarRatingRow(title: "Toilet Paper", value: $tpRating)
                        StarRatingRow(title: "Cleanliness", value: $cleanliness)
                        StarRatingRow(title: "Privacy", value: $privacy)
                        StarRatingRow(title: "Plumbing", value: $plumbing)
                        StarRatingRow(title: "Overall Vibes", value: $overallVibes)
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.thinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    // Comment
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Comment")
                            .font(.subheadline.weight(.semibold))
                        TextField("How was it?", text: $comment, axis: .vertical)
                            .lineLimit(3, reservesSpace: true)
                            .textInputAutocapitalization(.sentences)
                            .padding(12)
                            .background(.ultraThinMaterial)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.thinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    // Photo picker
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Photo (optional)")
                            .font(.subheadline.weight(.semibold))

                        if let data = imageData, let ui = UIImage(data: data) {
                            Image(uiImage: ui)
                                .resizable()
                                .scaledToFill()
                                .frame(height: 160)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                                .overlay(alignment: .topTrailing) {
                                    Button {
                                        pickerItem = nil
                                        imageData = nil
                                        imageURL = nil
                                    } label: {
                                        Image(systemName: "xmark.circle.fill")
                                            .imageScale(.large)
                                            .symbolRenderingMode(.hierarchical)
                                    }
                                    .padding(8)
                                }
                        } else {
                            PhotosPicker(selection: $pickerItem, matching: .images) {
                                HStack {
                                    Image(systemName: "photo.on.rectangle")
                                    Text("Choose Photo")
                                    Spacer()
                                }
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(.ultraThinMaterial)
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                            }
                            .onChange(of: pickerItem) { _, newItem in
                                Task { await loadPhoto(from: newItem) }
                            }
                        }
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(.thinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                }
                .padding(.horizontal)
            }

            // Bottom Save (full-width)
            Button(action: save) {
                HStack {
                    Spacer()
                    if isSaving { ProgressView() }
                    else { Text("Save").fontWeight(.bold) }
                    Spacer()
                }
            }
            .buttonStyle(.borderedProminent)
            .disabled(isSaving)
            .padding()
        }
        .task {
            if locationDescription.isEmpty { await reverseGeocodeCurrent() }
        }
        .alert("Error", isPresented: .constant(errorMessage != nil)) {
            Button("OK") { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
        .navigationTitle("Log Poop")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button("Cancel") { dismiss() }
            }
        }
    }

    // MARK: - Save  👇👇👇  (this is the one you asked about)

    func save() {
        guard !isSaving else { return }
        isSaving = true

        // ✅ Ensure we write the SAME userID that Dashboard queries
        let d = UserDefaults.standard
        let uid = auth.currentUserRecordID?.recordName
            ?? d.string(forKey: "auth.apple.userID")
            ?? d.string(forKey: "auth.user.recordName")
            ?? "unknown"

        // Display name
        let name: String = {
            let n = auth.currentUserName.trimmingCharacters(in: .whitespacesAndNewlines)
            if !n.isEmpty && n.lowercased() != "user" { return n }
            if let stored = d.string(forKey: "auth.displayName"), !stored.isEmpty { return stored }
            return "User"
        }()

        let color: Color? = nil
        let groupID = groups.currentGroupID
        let coord = locationManager.currentCoordinate

        poopManager.addPoopPin(
            userID: uid,
            userName: name,
            userColor: color,
            groupID: groupID,
            coordinate: coord,
            locationDescription: locationDescription,
            tpRating: tpRating,
            cleanliness: cleanliness,
            privacy: privacy,
            plumbing: plumbing,
            overallVibes: overallVibes,
            comment: comment,
            photoURL: imageURL
        )

        // Done
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            isSaving = false
            dismiss()
        }
    }

    // MARK: - Helpers

    private func reverseGeocodeCurrent() async {
        let loc = CLLocation(latitude: locationManager.currentCoordinate.latitude,
                             longitude: locationManager.currentCoordinate.longitude)
        do {
            let placemarks = try await geocoder.reverseGeocodeLocation(loc)
            if let first = placemarks.first {
                let pieces = [first.name, first.locality, first.administrativeArea]
                    .compactMap { $0 }
                    .joined(separator: ", ")
                if !pieces.isEmpty {
                    locationDescription = pieces
                }
            }
        } catch {
            // ignore
        }
    }

    private func loadPhoto(from item: PhotosPickerItem?) async {
        guard let item else { return }
        do {
            if let data = try await item.loadTransferable(type: Data.self) {
                self.imageData = data
                let tmp = FileManager.default.temporaryDirectory
                    .appendingPathComponent(UUID().uuidString).appendingPathExtension("jpg")
                try data.write(to: tmp)
                self.imageURL = tmp
            }
        } catch {
            await MainActor.run {
                self.errorMessage = "Could not load photo."
            }
        }
    }
}

// MARK: - Uses your existing StarRatingView(rating:label:)
struct StarRatingRow: View {
    let title: String
    @Binding var value: Int

    var body: some View {
        StarRatingView(rating: $value, label: title)
    }
}
