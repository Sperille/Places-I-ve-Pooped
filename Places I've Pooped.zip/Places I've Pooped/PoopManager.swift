//
//  PoopManager.swift
//  Places I've Pooped
//

import Foundation
import CloudKit
import CoreLocation
import SwiftUI
import Network
#if canImport(UIKit)
import UIKit
#endif

final class PoopManager: ObservableObject {
    @Published var poopPins: [PoopPin] = []
    @Published var lastAddedPin: PoopPin?            // MapView centers on this
    @Published var comments: [PoopComment] = []      // for PoopDetailView

    private let db = CKContainer.default().privateCloudDatabase

    // Offline retry
    private var pendingRecords: [CKRecord] = []
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "PoopManager.Network")

    init() { startNetworkMonitor() }

    // MARK: - Pins

    func fetchPoopPins() {
        let q = CKQuery(recordType: "PoopPin", predicate: NSPredicate(value: true))
        q.sortDescriptors = [NSSortDescriptor(key: "createdAt", ascending: false)]
        db.perform(q, inZoneWith: nil) { [weak self] recs, err in
            guard let self else { return }
            if let err { print("❌ fetchPoopPins: \(err.localizedDescription)"); return }
            let pins = (recs ?? []).compactMap { PoopManager.pin(from: $0) }
            DispatchQueue.main.async { self.poopPins = pins }
        }
    }

    /// Optimistic add → shows immediately, saves in background, replaces with server copy
    func addPoopPin(
        userID: String,
        userName: String,
        userColor: Color?,
        groupID: String?,
        coordinate: CLLocationCoordinate2D,
        locationDescription: String,
        tpRating: Int,
        cleanliness: Int,
        privacy: Int,
        plumbing: Int,
        overallVibes: Int,
        comment: String,
        photoURL: URL? = nil
    ) {
        let local = PoopPin(
            id: "temp.\(UUID().uuidString)",
            userID: userID,
            groupID: groupID,
            coordinate: coordinate,
            tpRating: tpRating,
            cleanliness: cleanliness,
            privacy: privacy,
            plumbing: plumbing,
            overallVibes: overallVibes,
            comment: comment,
            userColor: userColor ?? .blue,
            userName: userName,
            locationDescription: locationDescription,
            createdAt: Date(),
            photoURL: photoURL
        )

        DispatchQueue.main.async {
            self.poopPins.insert(local, at: 0)
            self.lastAddedPin = local
        }

        let rec = CKRecord(recordType: "PoopPin")
        rec["userID"] = userID as CKRecordValue
        if let groupID { rec["groupID"] = groupID as CKRecordValue }
        rec["location"] = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
        rec["locationDescription"] = locationDescription as CKRecordValue
        rec["tpRating"] = tpRating as CKRecordValue
        rec["cleanliness"] = cleanliness as CKRecordValue
        rec["privacy"] = privacy as CKRecordValue
        rec["plumbing"] = plumbing as CKRecordValue
        rec["overallVibes"] = overallVibes as CKRecordValue
        rec["comment"] = comment as CKRecordValue
        rec["userName"] = userName as CKRecordValue
        rec["createdAt"] = Date() as CKRecordValue
        if let userColor { rec["userColorHex"] = ColorCoding.hexString(from: userColor) as CKRecordValue }
        if let photoURL { rec["photo"] = CKAsset(fileURL: photoURL) }

        db.save(rec) { [weak self] saved, err in
            guard let self else { return }
            if let err {
                print("⚠️ addPoopPin save failed, will retry: \(err.localizedDescription)")
                self.enqueueForRetry(rec)
                return
            }
            guard let saved, let savedPin = PoopManager.pin(from: saved) else { return }
            DispatchQueue.main.async {
                if let idx = self.poopPins.firstIndex(where: { $0.id == local.id }) {
                    self.poopPins[idx] = savedPin
                } else {
                    self.poopPins.insert(savedPin, at: 0)
                }
                self.lastAddedPin = savedPin
            }
        }
    }

    private static func pin(from record: CKRecord) -> PoopPin? {
        guard
            let loc = record["location"] as? CLLocation,
            let tp = record["tpRating"] as? Int,
            let clean = record["cleanliness"] as? Int,
            let priv = record["privacy"] as? Int,
            let plum = record["plumbing"] as? Int,
            let vibes = record["overallVibes"] as? Int,
            let comment = record["comment"] as? String,
            let userID = record["userID"] as? String,
            let userName = record["userName"] as? String,
            let createdAt = (record["createdAt"] as? Date)
        else { return nil }

        let groupID = record["groupID"] as? String
        let locDesc = (record["locationDescription"] as? String) ?? ""
        let colorHex = (record["userColorHex"] as? String)
        let color = ColorCoding.color(fromHex: colorHex) ?? .blue
        let photoAsset = record["photo"] as? CKAsset
        let photoURL = photoAsset?.fileURL

        return PoopPin(
            id: record.recordID.recordName,
            userID: userID,
            groupID: groupID,
            coordinate: CLLocationCoordinate2D(latitude: loc.coordinate.latitude, longitude: loc.coordinate.longitude),
            tpRating: tp,
            cleanliness: clean,
            privacy: priv,
            plumbing: plum,
            overallVibes: vibes,
            comment: comment,
            userColor: color,
            userName: userName,
            locationDescription: locDesc,
            createdAt: createdAt,
            photoURL: photoURL
        )
    }

    // MARK: - Comments

    struct PoopComment: Identifiable {
        let id: String
        let poopID: String
        let userID: String
        let userName: String
        let text: String
        let createdAt: Date
    }

    // MARK: - Comments (group + friends visibility)

    func fetchComments(
        for poop: PoopPin,
        viewerID: String?,
        viewerFriendIDs: [String],
        viewerGroupID: String?
    ) {
        // Base: only comments for this poop
        let base = NSPredicate(format: "poopID == %@", poop.id)

        // Visibility: group OR friends-of-viewer OR viewer themself OR poop owner
        var ors: [NSPredicate] = [
            NSPredicate(format: "userID == %@", poop.userID)
        ]
        if let vid = viewerID {
            ors.append(NSPredicate(format: "userID == %@", vid))
        }
        if !viewerFriendIDs.isEmpty {
            ors.append(NSPredicate(format: "userID IN %@", viewerFriendIDs))
        }
        if let gid = viewerGroupID, !gid.isEmpty {
            ors.append(NSPredicate(format: "groupID == %@", gid))
        }

        let visibility = NSCompoundPredicate(orPredicateWithSubpredicates: ors)
        let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [base, visibility])

        let q = CKQuery(recordType: "Comment", predicate: predicate)
        q.sortDescriptors = [NSSortDescriptor(key: "createdAt", ascending: true)]

        // Comments are shared → public DB
        let publicDB = CKContainer.default().publicCloudDatabase
        publicDB.perform(q, inZoneWith: nil) { [weak self] recs, err in
            guard let self else { return }
            if let err { print("❌ fetchComments:", err.localizedDescription); return }
            let items: [PoopComment] = (recs ?? []).compactMap { r in
                guard
                    let poopID = r["poopID"] as? String,
                    let userID = r["userID"] as? String,
                    let userName = r["userName"] as? String,
                    let text = r["text"] as? String,
                    let createdAt = r["createdAt"] as? Date
                else { return nil }
                return PoopComment(id: r.recordID.recordName,
                                   poopID: poopID,
                                   userID: userID,
                                   userName: userName,
                                   text: text,
                                   createdAt: createdAt)
            }
            DispatchQueue.main.async { self.comments = items }
        }
    }

    func addComment(
        for poop: PoopPin,
        userID: String,
        userName: String,
        text: String,
        completion: ((Result<Void, Error>) -> Void)? = nil
    ) {
        let r = CKRecord(recordType: "Comment")
        r["poopID"] = poop.id as CKRecordValue
        r["userID"] = userID as CKRecordValue
        r["userName"] = userName as CKRecordValue
        r["text"] = text as CKRecordValue
        r["createdAt"] = Date() as CKRecordValue
        if let gid = poop.groupID { r["groupID"] = gid as CKRecordValue } // scope to group when applicable

        let publicDB = CKContainer.default().publicCloudDatabase
        publicDB.save(r) { [weak self] saved, err in
            guard let self else { return }
            if let err {
                DispatchQueue.main.async { completion?(.failure(err)) }
                return
            }
            let item = PoopComment(id: saved?.recordID.recordName ?? UUID().uuidString,
                                   poopID: poop.id,
                                   userID: userID,
                                   userName: userName,
                                   text: text,
                                   createdAt: Date())
            DispatchQueue.main.async {
                self.comments.append(item)  // optimistic append
                completion?(.success(()))
            }
        }
    }


    // MARK: - Offline retry

    private func enqueueForRetry(_ record: CKRecord) {
        queue.async { self.pendingRecords.append(record) }
    }

    private func startNetworkMonitor() {
        monitor.pathUpdateHandler = { [weak self] path in
            guard let self else { return }
            if path.status == .satisfied { self.flushPending() }
        }
        monitor.start(queue: queue)
    }

    private func flushPending() {
        guard !pendingRecords.isEmpty else { return }
        let batch = pendingRecords
        pendingRecords.removeAll()

        for rec in batch {
            db.save(rec) { [weak self] saved, err in
                guard let self else { return }
                if let err {
                    print("♻️ retry failed, requeue: \(err.localizedDescription)")
                    self.enqueueForRetry(rec)
                    return
                }
                if let saved, let pin = PoopManager.pin(from: saved) {
                    DispatchQueue.main.async {
                        if let idx = self.poopPins.firstIndex(where: { $0.id == rec.recordID.recordName }) {
                            self.poopPins[idx] = pin
                        } else {
                            self.poopPins.insert(pin, at: 0)
                        }
                        self.lastAddedPin = pin
                    }
                }
            }
        }
    }
}

// MARK: - Color coding helpers
private enum ColorCoding {
    static func hexString(from color: Color) -> String {
        #if canImport(UIKit)
        let ui = UIColor(color)
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard ui.getRed(&r, green: &g, blue: &b, alpha: &a) else { return "#007AFF" }
        let R = Int(round(r * 255)), G = Int(round(g * 255)), B = Int(round(b * 255))
        return String(format: "#%02X%02X%02X", R, G, B)
        #else
        return "#007AFF"
        #endif
    }

    static func color(fromHex hex: String?) -> Color? {
        guard let hex else { return nil }
        let cleaned = hex.trimmingCharacters(in: CharacterSet(charactersIn: "#")).uppercased()
        guard let rgb = UInt32(cleaned, radix: 16) else { return nil }
        let r = CGFloat((rgb >> 16) & 0xFF) / 255.0
        let g = CGFloat((rgb >> 8) & 0xFF) / 255.0
        let b = CGFloat(rgb & 0xFF) / 255.0
        #if canImport(UIKit)
        return Color(UIColor(red: r, green: g, blue: b, alpha: 1))  // labeled args ✅
        #else
        return Color(red: Double(r), green: Double(g), blue: Double(b), opacity: 1)
        #endif
    }
}
