//
//  PoopPin.swift
//  Places I've Pooped
//
//  Created by Steven Perille on 8/4/25.
//

import Foundation
import CoreLocation
import SwiftUI

struct PoopPin: Identifiable {
    let id: String
    let userID: String
    let groupID: String?
    let coordinate: CLLocationCoordinate2D
    let tpRating: Int
    let cleanliness: Int
    let privacy: Int
    let plumbing: Int
    let overallVibes: Int
    let comment: String
    let userColor: Color
    let userName: String
    let locationDescription: String
    let createdAt: Date
    let photoURL: URL?
}
