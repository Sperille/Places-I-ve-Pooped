//
//  SearchAndCreateGroupView.swift
//  Places I've Pooped
//

import SwiftUI

struct SearchAndCreateGroupView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var groupsManager: GroupsManager

    @State private var newGroupName: String = ""
    @State private var isCreating: Bool = false
    @State private var createError: String?

    var body: some View {
        VStack(spacing: 12) {
            TextField("New group name", text: $newGroupName)
                .textInputAutocapitalization(.words)
                .disableAutocorrection(true)

            if let createError {
                Text(createError)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            Button {
                createGroup()
            } label: {
                if isCreating {
                    ProgressView()
                } else {
                    Text("Create Group")
                        .fontWeight(.semibold)
                }
            }
            .disabled(isCreating || newGroupName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

            Spacer(minLength: 0)
        }
        .padding()
    }

    private func createGroup() {
        let name = newGroupName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return }
        isCreating = true
        createError = nil

        groupsManager.createGroup(name: name) { result in
            isCreating = false
            switch result {
            case .success:
                dismiss()
            case .failure(let error):
                createError = (error as NSError).localizedDescription
            }
        }
    }
}
