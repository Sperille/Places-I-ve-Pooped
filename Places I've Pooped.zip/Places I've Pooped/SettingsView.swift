//
//  SettingsView.swift
//  Places I've Pooped
//
//  Created by Steven Perille on 7/6/25.
//

import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Button("Close") {
                    dismiss()
                }
                .foregroundColor(Color(hex: "#6B4F3B"))
                .fontWeight(.semibold)
                
                Spacer()
            }

            Text("Settings")
                .font(.largeTitle)
                .bold()
                .padding(.top, 10)

            Divider()

            Text("App Settings")
                .font(.headline)

            Text("")

            Spacer()
        }
        .padding()
    }
}
