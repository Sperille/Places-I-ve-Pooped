//
//  UserManager.swift
//  Places I've Pooped
//
//  Created by Steven Perille on 7/6/25.
//

import Foundation
import CloudKit
import SwiftUI
import AuthenticationServices

struct Friend: Identifiable {
    var id: String
    var name: String
}

class UserManager: ObservableObject {
    @Published var currentUserID: String?
    @Published var currentUserName: String?
    @Published var friends: [Friend] = []

    private let privateDB = CKEnv.privateDB

    // MARK: - Login with email/password
    func login(email: String, password: String, completion: @escaping (Bool, String?) -> Void) {
        let predicate = NSPredicate(format: "email == %@ AND password == %@", email, password)
        let query = CKQuery(recordType: "User", predicate: predicate)

        privateDB.perform(query, inZoneWith: nil) { records, error in
            DispatchQueue.main.async {
                guard let user = records?.first else {
                    completion(false, "Invalid credentials")
                    return
                }

                self.currentUserID = user.recordID.recordName
                self.currentUserName = user["username"] as? String
                completion(true, nil)
            }
        }
    }

    // MARK: - Register
    func register(email: String, password: String, username: String, completion: @escaping (Bool, String?) -> Void) {
        let record = CKRecord(recordType: "User")
        record["email"] = email
        record["password"] = password
        record["username"] = username
        record["signInMethod"] = "email"

        privateDB.save(record) { saved, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(false, error.localizedDescription)
                } else {
                    self.currentUserID = saved?.recordID.recordName
                    self.currentUserName = username
                    completion(true, nil)
                }
            }
        }
    }

    // MARK: - Add Friend
    func addFriend(byCode code: String, completion: @escaping (Bool) -> Void) {
        let recordID = CKRecord.ID(recordName: code)
        privateDB.fetch(withRecordID: recordID) { record, error in
            DispatchQueue.main.async {
                guard let record = record else {
                    completion(false)
                    return
                }

                let friend = Friend(id: record.recordID.recordName, name: record["username"] as? String ?? "Unknown")
                if !self.friends.contains(where: { $0.id == friend.id }) {
                    self.friends.append(friend)
                }

                completion(true)
            }
        }
    }

    // MARK: - Apple Sign-In
    func handleAppleSignIn(credential: ASAuthorizationCredential) {
        if let appleIDCredential = credential as? ASAuthorizationAppleIDCredential {
            let userID = appleIDCredential.user
            let email = appleIDCredential.email ?? "unknown@email.com"
            let username = appleIDCredential.fullName?.givenName ?? "User"

            currentUserID = userID
            currentUserName = username

            let recordID = CKRecord.ID(recordName: userID)
            privateDB.fetch(withRecordID: recordID) { existing, error in
                if existing != nil {
                    print("✅ Apple ID already exists")
                } else {
                    let record = CKRecord(recordType: "User", recordID: recordID)
                    record["email"] = email
                    record["username"] = username
                    record["password"] = "apple" // placeholder
                    record["signInMethod"] = "apple"

                    self.privateDB.save(record) { _, error in
                        if let error = error {
                            print("❌ Failed to save Apple user: \(error.localizedDescription)")
                        }
                    }
                }
            }
        }
    }
}
